//import logo from './logo.svg';
import './App.css';
import { useState } from 'react';

import { Button } from 'react-bootstrap';
import Modal from "react-bootstrap/Modal";
import "bootstrap/dist/css/bootstrap.min.css";
//npm run startimport TreeList from 'react-treelist';
import 'react-treelist/build/css/index.css';
import { makeStyles } from '@material-ui/core/styles';
import TreeView from '@material-ui/lab/TreeView';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import ChevronRightIcon from '@material-ui/icons/ChevronRight';
import TreeItem from '@material-ui/lab/TreeItem';

function App() {
   const [title,setTitle]=useState('');
   const [childListOfDeleted,setChildListOfDeleted]=useState([]); 
   const [childTitle,setChildTitle]=useState('');
   const [newTitle,setNewTitle]=useState('');
   const [parentIdOfDeleted,setParentIdOfDeleted]=useState(''); 
   const [parentIdForDelete,setParentIdForDelete]=useState('');
   const[searchedChild,setSearchedChild]=useState([]);
   const [idCounter,setCounter]=useState(1);
   const [menuList, setList] = useState([]);
   const [childList, setChildList] = useState([]);
   const [editedId,setEditedId]=useState('');
   const [parentId,setParentId]=useState('');
  const [showChild, setShowChild] = useState(false);
  const [showEdit, setShowEdit] = useState(false);
   const [hasChild, setHasChild] = useState(false);
   const[continueSearch,setContinueSearch]=useState(false);
   const[deletionCompletion,setDeletionCompletion]=useState(false);
   const handleClose = () => setShowChild(false);
   const useStyles = makeStyles({
    root: {
      height: 216,
      flexGrow: 1,
      maxWidth: 400,
    }
  });
   const classes = useStyles();
   const [expanded, setExpanded] = useState([]);
   const [selected, setSelected] = useState([]);
 
   const handleSelect = (event, nodeIds) => {
    setSelected(nodeIds);
  };
  
    const handleToggle = (event, nodeIds) => {
      setExpanded(nodeIds);
    }
    const renderTree = (nodes) => (
      
     
      <TreeItem key={nodes.id} nodeId={nodes.id} label={nodes.value}>
       <Button bsStyle="primary" id={nodes.id} onClick={(e) => handleEditTitle(e.currentTarget.id)}>Edit</Button>
       <Button bsStyle="primary" id={nodes.id}  onClick={(e) => handleDelete(e.target.id)}>Delete</Button>
               <Button bsStyle="primary" id={nodes.id} onClick={(e)=>handleShowChild(e.currentTarget.id)}  >Add Child </Button>
        {Array.isArray(nodes.childList) ? nodes.childList.map((node) => renderTree(node)) : null}
      </TreeItem>
    );
   const handleShowChild = (id) =>
   { setShowChild(true);
    setParentId(id);
   }
   const handleEditTitle = (id) =>{ 
     console.log(" target "+id);
     setShowEdit(true);
     setEditedId(id);
   }
   const handleclick=()=>
   {
     console.log({title});
    // setRoot(title);
     setCounter(idCounter+1);
     const newList = menuList.concat({value:title,id:idCounter,parentId:0,childList:[]});    
    setList(newList);
    setTitle();
   }
  
    function searchChild(children,id)
    { 
       console.log("inside search" + children);
      children.forEach((child)=>{
        console.log("child.id"+ child.id);
        if(child.id.toString()!==id.toString())
        {
         // searchedChild.push(child);
          console.log("After push"+ child.id);
          if(child.childList.length>0)
          {
            searchChild(child.childList,id);
          }
        }
       
      })
      return searchedChild;
    }
   

const removeFromParent=(child,parentId,deletedId) =>
{
  var counter=1;
	if(child.id.toString()!==parentId)
          {
          if(child.childList.length>0)
          {
            console.log("looking in next level");
            child.childList.forEach((item)=>{
              console.log("counter"+counter++);
             removeFromParent(item,parentId);
            })
                
          }
          }
        else
        {
          console.log("i am here"+ parentId);
              var childL=[];
              var clength=0;
              child.childList.forEach((child)=> 
                {
                  console.log("counter"+counter++);
                  if(child.id.toString() !==deletedId)
                  {
                    childL.push(child);
                  }
                  
                })

              console.log("item.childList"+ childL.length);
              child.childList=childL;
              if(childL.length === 0)
              {
                child.hasChild=false;
              }
             
      //        return child;
              
       
            }
            setDeletionCompletion(true);
           
              console.log(child);
              if(counter=clength)
              {
                console.log("returning nw");
            return child;
              }
}
const handleDelete=(id)=>
    {
      console.log("indsie delete of", id);
        var newList = [];
        var parentId='';
        var findparent=true;
        var idAfterHelper='';
        menuList.forEach((item) => {
         console.log("inside find parent of  "+item.id+"for deletion of" +id);
         if(findparent)
         {
         if(item.id.toString()===id)
         {
           parentId=0;
           console.log("root");
         }
        else
         {
           
         item.childList.forEach(( child)=>{
          var stopCheck=false;
           if(!stopCheck)
         idAfterHelper= deleteHelper(child,id);
          console.log("after helper" + idAfterHelper);

          if(idAfterHelper!==null)
          {
          findparent=false;
          stopCheck=true;
          console.log("stopping search");
         }
          
         })
        }
      }
         })
        
      console.log("idAfterHelper"+ idAfterHelper);
        if(parentId===0)
        {
          console.log("deleting root");
          menuList.forEach((item) =>{
            if(item.id.toString()!==id.toString())

            { 
              console.log("adding id to list" + item.id,id)
              newList.push(item);
            }
          })
        }
        else
        {
          console.log("deleting a child"); var deletionDone=false;
          parentId=idAfterHelper;
          console.log("parentId"+parentId);
          menuList.forEach((item) =>{
            var checkchild=true;
            console.log( "item to deleted" +item.id ,parentId)
            if(!deletionDone)
            {
            if(item.id.toString()===parentId)
            { 
              console.log("i am here"+ parentId);
              var childL=[];
              console.log(item.childList);
              item.childList.forEach((child)=> 
                {
                  console.log("item id of the child" + child.id);
                  if(child.id.toString() !==id.toString())
                  {
                    childL.push(child);
                  }
                  
                })

              console.log("item.childList"+ childL.length);
              item.childList=childL;
              if(childL.length === 0)
              {
                item.hasChild=false;
                item.childList=[];
              }
              console.log("inside item push"+item.id,item.childList,item.parentId);
              newList.push(item);
              deletionDone=true;
              checkchild=false;
            }
            if(checkchild)
            {
            if(item.childList.length>0)
              {
                var children=[];
                item.childList.forEach((child)=> {
                  console.log("checking for child with id" + child.id);
                     children=  removeFromParent(child,parentId,id);
                     if( children!=null)
                     {
                       console.log("adding child");
              item.childList.push(children);
                     }
                    })
              console.log("inside item push"+item.id,item.childList,item.parentId);
              newList.push(item);
              //newList.forEach((item)=>
       // {
       //   console.log("value"+ item.value);
       //   item.childList.forEach((child)=>
       //   {
       //     console.log("child"+ child.value);
       //   }
       // )
       // })
              console.log("deletionCompletion "+ deletionCompletion);
             // deletionDone=deletionCompletion;
               
              }
            }
          }
           else
           { 
              console.log("adding items after delete");
              newList.push(item)
           }
            
          })
        }
        console.log("setting list"+ newList);
        newList.forEach((item)=>
        {
          console.log("value"+ item.value);
        })
        setList(newList);
    }
        //
const deleteHelper =(child,deletedId)=>
{ 
   console.log("inside deleteHelper for child id" + child.value);
   var findParent =true;
   var parent='';
   var parentId1='';
   if(findParent)
   {
     console.log("inside loop for"+ child.id);
   if(child.id.toString() ===deletedId.toString())
      {
         console.log("child.parentId.toString()" +child.parentId.toString());
        // setParentIdForDelete(child.parentId.toString());
        // console.log("parentIdOfDeleted set to"+ parentIdForDelete);
         findParent=false;
         parent=child.parentId;
         return parent;
        
         ;
      }
    if(child.id.toString() !==deletedId.toString())
      {
        if(child.childList.length>0)
      {
         parentId1='';
        console.log("looking in next level");
        child.childList.forEach((item)=>{
          parentId1= deleteHelper(item,deletedId);
           console.log(parentId);
           if(parentId1!==null)
           {
             console.log("dfdf");
             setParentIdForDelete(parentId1);
             console.log("parentIdOfDeleted"+ parentIdForDelete)
           }
           return parentId1;
        })
        
      }
     
      }    
    }
      
  //console.log("setting parent list null");
  console.log("before returning null");
  if(parentId1!==null)
  {
    console.log("returnig " + parentId1);
    return parentId1;
  }
  if (parentId!==null)
  {
  //(parentId==null)
  console.log(parentId);
    return parentId;
  }

    }
    function searchInChild(child,deletedChild)
    { 
       console.log("inside searchChildUsingId" + child.id);
       var lookforChild=true;
        if(child.id.toString() ===parentId.toString())
          {
                      child.childList.push({value:childTitle,id:idCounter,parentId:parentId,childList:[]});
                      child.hasChild=true;
                      lookforChild=false;
          }
          if(lookforChild && child.childList.length>0)
          {
            console.log("looking in next level");
            child.childList.forEach((item)=>{
              searchChildUsingId(item,parentId);
            })
            
          }
          
      console.log("setting parent list null");
      return childList;
    }
    function searchChildUsingId(child,parentId)
    { 
       console.log("inside searchChildUsingId" + child.id);
       var lookforChild=true;
        if(child.id.toString() ===parentId.toString())
          {
                      child.childList.push({value:childTitle,id:idCounter,parentId:parentId,childList:[]});
                      child.hasChild=true;
                      lookforChild=false;
          }
          if(lookforChild && child.childList.length>0)
          {
            console.log("looking in next level");
            child.childList.forEach((item)=>{
              searchChildUsingId(item,parentId);
            })
            
          }
          
      console.log("setting parent list null");
      return childList;
    }
    function findEditedUsingId(child,editedId)
    { 
       console.log("inside findEditedUsingId FOR" + child.id);
       console.log("inside findEditedUsingId EDITED" + editedId);
       var lookforChild=true;
       var editedChildList=[];
        if(child.id.toString() ===editedId.toString())
          {
                child.value=newTitle;
                //editedChildList.push(child);
                 lookforChild=false;
          }
          if(lookforChild && child.childList.length>0)
          {
            console.log("looking in next level");
            child.childList.forEach((item)=>{
              findEditedUsingId(item,editedId);
            })
            
          }
         
          console.log(child)
   //   console.log("setting parent list null");
      return child;
    }
   const handleEdit=()=>
   {
  //const [showEdit, setShowEdit] = useState(false);
  setShowEdit(false);
     var newList = [];    
    console.log(newTitle +"addedd");
     menuList.forEach((item) => {
// console.log("inside each "+item.id);
      if(item.id.toString()=== editedId.toString())
      {     
        item.value=newTitle;
        newList.push(item);
      }
      else if(item.childList.length>0)
      {
        
        console.log(item.childList.length);
        var editedChildList=[];
        item.childList.forEach((child)=>
        {
          console.log(child.value);
         // if(child.id.toString()=== editedId.toString())
          //{     
         //   child.value=newTitle;
         //   editedChildList.push(child);
          //  item.childList=editedChildList;
          //}
         // else
         // {
         //   editedChildList.push(child);
          //} 
          var afterEditChild=   findEditedUsingId(child,editedId);
              //  setContinueSearch(false);
              console.log( afterEditChild);
          editedChildList.push(afterEditChild);
      })
      item.childList=editedChildList;
       console.log("pushing the new item to the list");
        newList.push(item);
      }
      else{
        newList.push(item);
      }
      
     })
     console.log(newList);
    setList(newList);
   }
     const handleSave=()=>
     {
       
       setShowChild(false);
        setCounter(idCounter+1);
        menuList.forEach((item) => {
           console.log("inside each "+item.id);
                if(item.id.toString()=== parentId.toString())
                {     
                  console.log("id matched for" + item.id);
                  item.childList.push({value:childTitle,id:idCounter,parentId:parentId,childList:[]});
                  item.hasChild=true;
               }
               else
               {
                 if(item.childList.length>0)
                  {
                 // item.childList.forEach((child ) =>
                 // {
                 //   if(child.id.toString()===parentId.toString())
                 //    {
                 //     child.childList.push({value:childTitle,id:idCounter,parentId:parentId,childList:[]});
                 // item.hasChild=true;

                 //    }
                 // })
                 // }
             //  }
             item.childList.forEach(( child)=>{
               
               if(!continueSearch)
               {
               var children=   searchChildUsingId(child,parentId);
                setContinueSearch(false);
              console.log(children.length);
               }
               else
               {
                 return;
               }
             }
             )
             
                  }
                }
              })
   // const newList = menuList.concat({value:childTitle,id:idCounter,parentId:parentId,childList:[]});    
   // setList(newList);
    console.log(menuList);
       }
  return (
    <div className="App">
        <label>Enter title</label>
        <input type="text" id="titleText" value={title} onChange={(e) =>setTitle(e.target.value)}></input>
        <Button bsStyle="primary" onClick={handleclick} >Add title</Button>
            
              <Modal show={showChild} onHide={handleClose}>
        <Modal.Header >
          <Modal.Title>Enter child's title</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <input type="text" id="childTitle"  onChange={(e) =>setChildTitle(e.target.value)} />
          <input type="hidden" value={parentId}/>
        </Modal.Body>

        <Modal.Footer>
          <Button variant="secondary" onClick={handleClose}>
            Close
          </Button>
          <Button variant="primary" onClick={handleSave}>
            Save Changes
          </Button>
        </Modal.Footer>
      </Modal>

      <Modal show={showEdit} onHide={handleClose}>
        <Modal.Header >
          <Modal.Title>Enter New title</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <input type="text" id="newTitle"  onChange={(e) =>setNewTitle(e.target.value)} />
          <input type="hidden" value={editedId}/>
        </Modal.Body>

        <Modal.Footer>
          <Button variant="secondary" onClick={handleClose}>
            Close
          </Button>
          <Button variant="primary" onClick={handleEdit}>
            Save Changes
          </Button>
        </Modal.Footer>
      </Modal>
      <TreeView
      className={classes.root}
      defaultCollapseIcon={<ExpandMoreIcon />}
      defaultExpandIcon={<ChevronRightIcon />}
      expanded={expanded}
      selected={selected}
      onNodeToggle={handleToggle}
      onNodeSelect={handleSelect}
    >
      
      {menuList.map((nodes) => (
        <TreeItem key={nodes.id} nodeId={nodes.id} label={nodes.value} >
        <Button bsStyle="primary" id={nodes.id}  onClick={(e) => handleEditTitle(e.currentTarget.id)}>Edit</Button>
                <Button bsStyle="primary" id={nodes.id}  onClick={(e) => handleDelete(e.target.id)}>Delete</Button>
               <Button bsStyle="primary" id={nodes.id} onClick={(e)=>handleShowChild(e.currentTarget.id)}  >Add Child </Button>
        {Array.isArray(nodes.childList) ? nodes.childList.map((node) => renderTree(node)) : null}
      </TreeItem>

      )
      ) 
      }
       
      </TreeView>
    </div>
  );
  
}

export default App;
